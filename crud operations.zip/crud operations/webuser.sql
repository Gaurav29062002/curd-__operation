Enter password: ****
Welcome to the MySQL monitor.  Commands end with ; or \g.
Your MySQL connection id is 19 to server version: 5.0.11-beta-nt

Type 'help;' or '\h' for help. Type '\c' to clear the buffer.

mysql> use neha;
Database changed
mysql> show tables;
+----------------+
| Tables_in_neha |
+----------------+
| employee       |
| orders         |
| person         |
| person1        |
| student        |
| student_info   |
+----------------+
6 rows in set (0.02 sec)

mysql> create table webuser(name varchar(20), email varchar(89),password varchar(78));
Query OK, 0 rows affected (0.24 sec)

mysql> insert into webuser('neha','kolte@gmail.com','pass');
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''neha','kolte@gmail.com','pass')' at line 1
mysql> insert into webuser values('neha','kolte@gmail.com','pass');
Query OK, 1 row affected (0.07 sec)

mysql> insert into webuser values('poonam','poonam@gmail.com','poonam');
Query OK, 1 row affected (0.06 sec)

mysql>